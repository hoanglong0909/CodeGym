create definer = root@localhost view testview as
select `classicmodels`.`employees`.`employeeNumber` AS `employeeNumber`,
       `classicmodels`.`employees`.`lastName`       AS `lastName`,
       `classicmodels`.`employees`.`firstName`      AS `firstName`,
       `classicmodels`.`employees`.`extension`      AS `extension`,
       `classicmodels`.`employees`.`email`          AS `email`,
       `classicmodels`.`employees`.`officeCode`     AS `officeCode`,
       `classicmodels`.`employees`.`reportsTo`      AS `reportsTo`,
       `classicmodels`.`employees`.`jobTitle`       AS `jobTitle`
from `classicmodels`.`employees`;

