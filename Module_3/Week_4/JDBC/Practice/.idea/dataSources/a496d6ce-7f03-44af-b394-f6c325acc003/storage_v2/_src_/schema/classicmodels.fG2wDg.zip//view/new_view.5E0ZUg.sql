create view new_view as
select `classicmodels`.`customers`.`phone` AS `phone`
from `classicmodels`.`customers`;

