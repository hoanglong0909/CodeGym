create view v_tbldetai as
select `exersice_4`.`tbldetai`.`Madt`       AS `Madt`,
       `exersice_4`.`tbldetai`.`Tendt`      AS `Tendt`,
       `exersice_4`.`tbldetai`.`Kinhphi`    AS `Kinhphi`,
       `exersice_4`.`tbldetai`.`Noithuctap` AS `soluong`
from `exersice_4`.`tbldetai`;

